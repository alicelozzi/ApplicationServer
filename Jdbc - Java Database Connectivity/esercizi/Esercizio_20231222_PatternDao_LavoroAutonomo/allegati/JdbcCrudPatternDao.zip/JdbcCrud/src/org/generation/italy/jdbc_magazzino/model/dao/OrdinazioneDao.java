package org.generation.italy.jdbc_magazzino.model.dao;

import java.sql.Connection;

public class OrdinazioneDao extends ADao {
	
	public OrdinazioneDao(Connection jdbcConnectionToDatabase) {
		super(jdbcConnectionToDatabase);
	}
	
	
}
