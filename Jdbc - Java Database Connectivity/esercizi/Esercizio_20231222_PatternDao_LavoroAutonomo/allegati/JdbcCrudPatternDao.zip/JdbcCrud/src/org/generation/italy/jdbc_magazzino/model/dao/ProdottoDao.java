package org.generation.italy.jdbc_magazzino.model.dao;

import java.sql.Connection;

public class ProdottoDao extends ADao {
	
	public ProdottoDao(Connection jdbcConnectionToDatabase) {
		super(jdbcConnectionToDatabase);
	}
	
}
