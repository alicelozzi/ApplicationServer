package org.generation.italy.jdbc_magazzino.model.entity;

public class Prodotto {

}
